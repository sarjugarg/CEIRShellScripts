
set -x
op_name=$1
D=$2
VAR=""
serverId="Sig-01"
#serverId=$2
output_path=/u01/ceirapp/cdrRecoveryProcess/

DAY=$(date -d "$D" '+%d')
MONTH=$(date -d "$D" '+%B')
YEAR=$(date -d "$D" '+%Y')
echo "Day: $DAY"
echo "Month: ${MONTH^^}"
echo "Year: $YEAR"

cd  /u01/ceirapp/scripts/recovery
./cleanUpFiles.sh $1 $YEAR ${MONTH^^} $DAY




