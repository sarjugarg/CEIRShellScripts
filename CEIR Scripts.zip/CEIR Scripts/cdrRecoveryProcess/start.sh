
set -x
op_name=$1
VAR=""
serverId="Sig-01"
#serverId=$2
output_path=/u01/ceirapp/cdrRecoveryProcess/
validate(){
query="select status from cdr_process_status where   process_name = 'scriptV2' and SERVER_ID = '$serverId' and  OPERATOR = '$op_name' order by id  desc fetch next 1 rows only "
filename=$1
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb << EOF
   SET ECHO OFF
   SET FEEDBACK OFF
   SET PAGES 0
   SET SERVEROUTPUT ON
   SET VERIFY OFF
   SET head on
   SET COLSEP ,
   SET TRIMSPOOL ON
   set trimout on
   set linesize 1000
   spool "$output_path/${filename}"
   ${query};
   spool off 
EOF
        `
}

status=`ps -ef | grep 'script_v2.sh' | grep -v vi  |  grep '$op_name' `
if [ "$status" != "$VAR" ]
then
 echo "Process Already Running"
else
 echo "Checking If Process Ended"
validate  "P1.txt"
wait $!
cd $output_path
result=`cat P1.txt| tr -d " \t\n\r" `
echo $result

#result="Start"

if [ "$result" == "Start" ]
then 
echo "Process terminated in between"
./additionRecoverScript.sh $1
echo "Starting scriptV2"
cd /u01/ceirapp/cdrpreprocessor/$op_name/
 ./run.sh recovery &
fi
fi
#cd $output_path
 
