set -x
op_name=$1
VAR=""
serverId="Sig-01"
#serverId=$2
output_path=/u01/ceirapp/cdrRecoveryProcess/
validate2(){
query="select created_on from cdr_process_status where status like 'End' and   process_name = 'scriptV2' and SERVER_ID = '$serverId' and  OPERATOR = '$op_name' order by id  desc fetch next 1 rows only "
filename=$1
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb << EOF
   SET ECHO OFF
   SET FEEDBACK OFF
   SET PAGES 0
   SET SERVEROUTPUT ON
   SET VERIFY OFF
   SET head on
   SET COLSEP ,
   SET TRIMSPOOL ON
   set trimout on
   set linesize 1000
   spool "$output_path/${filename}"
   ${query};
   spool off 
EOF
        `
}
validate2  "P2.txt"
wait $!
cd $output_path
result2=`cat P2.txt| tr -d " \t\n\r" | cut -c1-9 `
echo $result2

rm P2.txt
startdate=$result2
enddate=$(date +%d-%b-%Y)
D=
n=0
until [ "$D" = "$enddate" ]
do  
   # ((n++))
    D=$(date -d "$startdate + $n days" +%d-%b-%Y)
    ((n++))
    echo $d
  # move files From processed to input 
   #  cd $output_path
   #  ./fileMoveNdLogStat.sh $1 $d
     
   DAY=$(date -d "$D" '+%d')
   MONTH=$(date -d "$D" '+%B')
   YEAR=$(date -d "$D" '+%Y')
   echo "Day: $DAY"
   echo "Month: ${MONTH^^}"
   echo "Year: $YEAR"
 cd  /u01/ceirapp/scripts/recovery
   ./cleanUpFiles.sh $1 $YEAR ${MONTH^^} $DAY
   
done

echo "Rec Proc Done"
