

#!/bin/bash 
set -x

#./home/ceirapp/.bash_profile


logfile="/u01/ceirapp/scripts/cdrMonthlyReports/logs.log"

query=" UPDATE cdr_file_delete_aud a SET a.RECORD_SIZE = ( select b.TOTAL_RECORDS from cdr_pre_processing_report b  where a.FILE_NAME = b.FILE_NAME and b.FILE_TYPE = 'I' fetch next 1 rows only   ) ;"




echo $query
updateSqlCount(){
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb >> $logfile << EOF
  $query
  commit;
EOF
        `	 
	}
 
updateSqlCount	


#!/bin/bash 
set -x

#./home/ceirapp/.bash_profile


logfile="/u01/ceirapp/scripts/cdrMonthlyReports/logs.log"

query=" UPDATE cdr_file_delete_aud a SET a.RECORD_SIZE = ( select b.TOTAL_RECORDS from cdr_pre_processing_report b  where a.FILE_NAME = b.FILE_NAME and b.FILE_TYPE = 'I' fetch next 1 rows only   ) ;"




echo $query
updateSqlCount(){
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb >> $logfile << EOF
  $query
  commit;
EOF
        `	 
	}
 
updateSqlCount	


#!/bin/bash 
set -x

#./home/ceirapp/.bash_profile


logfile="/u01/ceirapp/scripts/cdrMonthlyReports/logs.log"

query=" UPDATE cdr_file_delete_aud a SET a.RECORD_SIZE = ( select b.TOTAL_RECORDS from cdr_pre_processing_report b  where a.FILE_NAME = b.FILE_NAME and b.FILE_TYPE = 'I' fetch next 1 rows only   ) ;"




echo $query
updateSqlCount(){
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb >> $logfile << EOF
  $query
  commit;
EOF
        `	 
	}
 
updateSqlCount	


#!/bin/bash 
set -x

#./home/ceirapp/.bash_profile


logfile="/u01/ceirapp/scripts/cdrMonthlyReports/logs.log"

query=" UPDATE cdr_file_delete_aud a SET a.RECORD_SIZE = ( select b.TOTAL_RECORDS from cdr_pre_processing_report b  where a.FILE_NAME = b.FILE_NAME and b.FILE_TYPE = 'I' fetch next 1 rows only   ) ;"




echo $query
updateSqlCount(){
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb >> $logfile << EOF
  $query
  commit;
EOF
        `	 
	}
 
updateSqlCount	


#!/bin/bash 
set -x

#./home/ceirapp/.bash_profile


logfile="/u01/ceirapp/scripts/cdrMonthlyReports/logs.log"

query=" UPDATE cdr_file_delete_aud a SET a.RECORD_SIZE = ( select b.TOTAL_RECORDS from cdr_pre_processing_report b  where a.FILE_NAME = b.FILE_NAME and b.FILE_TYPE = 'I' fetch next 1 rows only   ) ;"




echo $query
updateSqlCount(){
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb >> $logfile << EOF
  $query
  commit;
EOF
        `	 
	}
 
updateSqlCount	


#!/bin/bash 
set -x

#./home/ceirapp/.bash_profile


logfile="/u01/ceirapp/scripts/cdrMonthlyReports/logs.log"

query=" UPDATE cdr_file_delete_aud a SET a.RECORD_SIZE = ( select b.TOTAL_RECORDS from cdr_pre_processing_report b  where a.FILE_NAME = b.FILE_NAME and b.FILE_TYPE = 'I' fetch next 1 rows only   ) ;"




echo $query
updateSqlCount(){
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb >> $logfile << EOF
  $query
  commit;
EOF
        `	 
	}
 
updateSqlCount	


#!/bin/bash 
set -x

#./home/ceirapp/.bash_profile


logfile="/u01/ceirapp/scripts/cdrMonthlyReports/logs.log"

query=" UPDATE cdr_file_delete_aud a SET a.RECORD_SIZE = ( select b.TOTAL_RECORDS from cdr_pre_processing_report b  where a.FILE_NAME = b.FILE_NAME and b.FILE_TYPE = 'I' fetch next 1 rows only   ) ;"




echo $query
updateSqlCount(){
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb >> $logfile << EOF
  $query
  commit;
EOF
        `	 
	}
 
updateSqlCount	

