
#!/bin/bash
set -x
#reportName="ReportFileStats1"
#reportName="ImeiDeltaDailyReport2"
#reportName="ImeiDeltaMonthlyReport2"
reportName="Opertor_model_monthly_report3"
op_name=$1
VAR=""
output_path=/u01/ceirapp/scripts/cdrMonthlyReports
cd $output_path
#time=$2
time=$(date "+%Y%m")
echo " Date $time"


#for time in 202101 202102 202103 202104 202105 202106
#do 
#$time=$val
src_name=""
if [ "$op_name" == "smart" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "metfone" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "cellcard" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "seatel" ]
then
	src_name=$(cat $op_name)
else
	echo "Operator not found"
fi
i=0
for j in 00
do
	array[$i]=$j;
	echo "for ${array[$i]}"
        status=`ps -ef | grep $reportName $2  ${array[$i]} | grep -v grep | grep java`
if [ "$status" != "$VAR" ]
then

echo "The process is already running"
else
echo "The process is not running.Starting the process for $reportName  $op_name  ${array[$i]}  $time "
java  -Dlog4j.configuration=file:./conf/${reportName}log4j.properties -cp ./lib/*:./CdrProcessses.jar com.gl.FileScpProcess.$reportName  $op_name  ${array[$i]}  $time &
echo "Process Started"

fi

done

#val 
#done


