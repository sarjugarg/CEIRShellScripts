#!/bin/bash
set -x
base_path="/u02/ceirdata/processed_cdr/$1/all/output/"
final_base_path="/u02/ceirdata/cdrprocessor/$1"
count=11
cd $base_path

updateSqlCount(){
query=$1
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb  << EOF
  $query
  commit;
    EOF `
   }
echo Starting
for filename in `ls -tr $base_path` ; do
query1="insert into cdr_file_details_db (status , FILE_NAME) values ( 'Init', '$filename' ) ;"	
if [ $j -lt $count ]
	then
		if [ -r "$filename" ]
		then
echo $filename
#                        updateSqlCount "$query1"
			mv $filename $final_base_path/$j/process/
			j=$((j+1))
		else
			continue
		fi
	else
		j=1
		mv $filename $final_base_path/$j/process/
 #               updateSqlCount "$query1"	
	        j=$((j+1))
	fi
done
echo Completed
