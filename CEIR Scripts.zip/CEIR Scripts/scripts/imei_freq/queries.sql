update device_usage_db set FEATURE_NAME='V' where TAC in(select DEVICE_ID from gsma_tac_db);
update device_usage_db set FEATURE_NAME='I' where TAC in(select TAC from GSMA_INVALID_TAC_DB );
update device_usage_db set FEATURE_NAME='U' WHERE FEATURE_NAME NOT IN ('I','V');
update device_duplicate_db set FEATURE_NAME='V' where TAC in(select DEVICE_ID from gsma_tac_db);
update device_duplicate_db set FEATURE_NAME='I' where TAC in(select TAC from GSMA_INVALID_TAC_DB );
update device_duplicate_db set FEATURE_NAME='U' WHERE FEATURE_NAME NOT IN ('I','V');
update imei_msisdn_dup_count_db set TAC_STATUS='V' where imei in(select IMEI from device_usage_db where FEATURE_NAME='V');
update imei_msisdn_dup_count_db set TAC_STATUS='I' where imei in(select IMEI from device_usage_db where FEATURE_NAME='I');
update imei_msisdn_dup_count_db set TAC_STATUS='U' where imei in(select IMEI from device_usage_db where FEATURE_NAME='U');
