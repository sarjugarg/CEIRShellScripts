#!/bin/bash
set -x
VAR=""
cd /u01/ceirapp/scripts/imei_freq/
build="imei_freq_report-1.0.jar"

dbStatusUpdate(){ 
p3_query=" insert into imei_msisdn_freq_db (MSISDN_FREQ,IMEI_COUNT,CREATED_ON,MODIFIED_ON) select msisdn_count, count(*) IMEI_COUNT, current_timestamp,current_timestamp  from (select IMEI, count(*) msisdn_count from (select IMEI,MSISDN from device_duplicate_db Union All select IMEI,MSISDN from device_usage_db) group by IMEI order by msisdn_count ASC) group by msisdn_count order by msisdn_count ASC "
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb << EOF
   ${p3_query};
    commit 
EOF
        `
}


status=`ps -efww | grep "$build $1 $2" |grep -v vi | grep java`
echo "$status"
if [ "$status" != "$VAR" ]
then
 echo "nothing"
 echo $status
else
 echo "to start"
 command="java -Dlog4j.configuration=file:./log4j.properties -jar $build -Dspring.config.location=:./application.properties  1> log.txt &"
 echo $command
#  $command  
   echo " java Process Done" 
dbStatusUpdate
echo "db status updated"
fi
