#!/bin/bash
set -x

. /home/ceirapp/.bash_profile

repdate=$(date +%F)
build="imei_freq_report-1.0.jar"
queries_file_path="/u01/ceirapp/scripts/imei_freq/"
filename="queries.sql"
truncate_query="truncate_table.sql"
logfile="/u01/ceirdata/scripts/imei_freq_logs/logs_$repdate.log"

run_query(){
$1=file_name
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb >>${logfile}<< EOF
    SET AUTOCOMMIT ON
   @${queries_file_path}${file_name}
  commit;
EOF
        `
sql_return_code=$?

if [ $sql_return_code != 0 ]
then
	echo "The update queries script failed" >> $logfile
	echo "Error code $sql_return_code" >> $logfile
	start_date_time=$(date "+%Y-%m-%d-%H:%M:%S")
	echo "Process terminated at  $start_date_time" >> $logfile
	exit 0;
fi
}

start_date_time=$(date "+%Y-%m-%d-%H:%M:%S")
echo "Started at $start_date_time" >> $logfile

start_date_time=$(date "+%Y-%m-%d-%H:%M:%S")
echo "Truncating table Imei-Msisdn Dup Count Db and Imei-Msisdn Freq Db at $start_date_time" >> $logfile

run_query "$truncate_query"

start_date_time=$(date "+%Y-%m-%d-%H:%M:%S")
echo "Going to start JAR at $start_date_time" >> $logfile

cd $queries_file_path
./start.sh &

t1=$?
start_date_time=$(date "+%Y-%m-%d-%H:%M:%S")
if [ "$t1" != 0 ]
then
	echo "JAR failed to start at $start_date_time" >> $logfile
else
	echo "JAR started at $start_date_time" >> $logfile
fi

status_final=`ps -ef | grep $build | grep -v grep |  grep -v vi | wc -l`
while [ "$status_final" -gt 0 ]
do
   echo "process running"
   status_final=`ps -ef | grep $build |  grep -v vi| wc -l`
   sleep 15
done

run_query "$filename"

start_date_time=$(date "+%Y-%m-%d-%H:%M:%S")
echo "Process Completed at $start_date_time" >> $logfile
