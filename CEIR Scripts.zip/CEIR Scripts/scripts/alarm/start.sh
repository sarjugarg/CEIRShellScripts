#!/bin/bash

cd /u01/ceirapp/scripts/alarm

VAR=""
echo $1 $2 $3
build="alarm-1.0.jar"

status=`ps -ef | grep $build | grep java`
if [ "$status" != "$VAR" ]
then
 echo "nothing"
 echo $status
else
 echo "to start"
 nohup java -Dlog4j.configuration=file:./log4j.properties -jar $build "$1" "$2" "$3" -Dspring.config.location=:./application.properties 1 > alarm.txt &
fi

exit 0
