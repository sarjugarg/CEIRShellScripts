#!/bin/bash

proc_location="/u01/ceirapp/CDR_copy"
operator=$1
source=$2

cd $proc_location
CP1=`./start.sh CP1 $operator $source`
cp1_status=$?
if [ $cp1_status != 0 ]
then
	echo "CP1 NOT STARTED"
	exit
fi

CP2=`./start.sh CP2 $operator $source`
cp2_status=$?
if [ $cp2_status != 0 ]
then
	echo "CP2 NOT STARTED"
	exit
fi
