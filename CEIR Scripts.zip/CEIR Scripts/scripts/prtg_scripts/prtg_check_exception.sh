# Return Values
RET_OK="0"
RET_WARN="1"
RET_CRIT="2"
RET_UNKN="3"

path=$1
############################################

cd $1
fileName=`find . -type f -printf '%T@ %p\n' | sort -n | tail -1 | cut -f2- -d" "|awk -F'/' '{print $2}'`
resp=`grep -q "Exception" $fileName;echo $?`

if [ "$resp" == 0 ]
then
        echo "1:1:Exception in $fileName"
        exit $RET_WARN
else
        echo "0:0:OK"
        exit $RET_OK
fi
