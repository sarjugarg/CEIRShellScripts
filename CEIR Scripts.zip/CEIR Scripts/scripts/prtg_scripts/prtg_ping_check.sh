#!/bin/sh

#0:0:OK=Process is runing
#1:1:Down=Process is down
#2=Process does not exist

# Return Values
RET_OK="0"
RET_WARN="1"
RET_CRIT="2"
RET_UNKN="3"

IP=$1

############################################

ping -c 1 $IP &> /dev/null

if [ $? -eq 0 ]; then
        echo "0:0:OK"
                exit $RET_OK
elif [ $? -ne 0 ]; then
        echo "1:1:Down"
                exit $RET_WARN
else
        echo "2"
                exit $RET_CRIT
fi
