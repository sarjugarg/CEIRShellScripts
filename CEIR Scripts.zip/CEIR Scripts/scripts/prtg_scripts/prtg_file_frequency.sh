#!/bin/sh

#0:0:OK=Process is runing
#1:1:Down=Process is down
#2=Process does not exist

# Return Values
RET_OK="0"
RET_WARN="1"
RET_CRIT="2"
RET_UNKN="3"

DATE=$(date "+%Y-%m-%d")
date24=$(date -d "-1 days" "+%Y-%m-%d")
date48=$(date -d "-2 days" "+%Y-%m-%d")
date72=$(date -d "-3 days" "+%Y-%m-%d")
############################################

current=`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//dmc-prod-db:1521/dmcproddb << EOF
SET ECHO OFF
   SET FEEDBACK OFF
   SET PAGES 0
   SET SERVEROUTPUT ON
   SET VERIFY OFF

   SET head on
   SET COLSEP ,
   SET TRIMSPOOL ON
   set trimout on
   set linesize 1000
   WHENEVER SQLERROR EXIT SQL.SQLCODE;
        select count(*) from cdr_file_delete_aud where created_on<=to_date('$DATE','YYYY-MM-DD') and created_on>=to_date('$date24','YYYY-MM-DD');
EOF
        `
sql_return_code=$?

if [ $sql_return_code != 0 ]
then
        echo "2:SQL ERROR CODE $sql_return_code"
        exit $RET_CRIT;
fi

previous=`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//dmc-prod-db:1521/dmcproddb << EOF
SET ECHO OFF
   SET FEEDBACK OFF
   SET PAGES 0
   SET SERVEROUTPUT ON
   SET VERIFY OFF

   SET head on
   SET COLSEP ,
   SET TRIMSPOOL ON
   set trimout on
   set linesize 1000
   WHENEVER SQLERROR EXIT SQL.SQLCODE;
        select count(*) from cdr_file_delete_aud where created_on<=to_date('$date24','YYYY-MM-DD') and created_on>=to_date('$date48','YYYY-MM-DD');
EOF
        `
sql_return_code=$?

if [ $sql_return_code != 0 ]
then
        echo "2:SQL ERROR CODE $sql_return_code"
        exit $RET_CRIT;
fi

diff=$((previous-current))
sum=$((current+previous))
percnt=$((diff*100/previous))

if [ "$percnt" -lt 5 ]
then
        echo "1:1:Less Than 5%"
        exit $RET_WARN
elif [ "$percnt" -ge 5 ]
then
        echo "0:0:OK"
        exit $RET_OK
else
        echo "3:Unknown Error"
        exit $RET_UNKN
fi
