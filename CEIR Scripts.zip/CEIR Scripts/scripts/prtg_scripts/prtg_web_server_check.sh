#!/bin/sh

#0:0:OK=Process is runing
#1:1:Down=Process is down
#2=Process does not exist

# Return Values
RET_OK="0"
RET_WARN="1"
RET_CRIT="2"
RET_UNKN="3"

MYURL=$1

############################################

STR=`curl -I -s "$MYURL" | head -n 1| awk '{print $2}'`

if [ "$STR" == "200" ]
then
  echo "0:0:OK" #OK - $MYURL On"
  exit $RET_OK
elif [ ! "$STR" ]
then
  echo "2"
  exit $RET_CRIT
else
  echo "1:1:Down"
  exit $RET_WARN
fi
