#!/bin/sh

#0:0:OK=Process is runing
#1:1:Down=Process is down
#2=Process does not exist

# Return Values
RET_OK="0"
RET_WARN="1"
RET_CRIT="2"
RET_UNKN="3"

path=$1

############################################

cd $path

if [ -d "$path" ]
then
        var=`find -cmin -5`
        if [ "$var" != "" ]
        then
                echo "0:0:OK"
                exit $RET_OK
        else
                echo "1:1:File Not Coming"
                exit $RET_WARN
        fi
else
        echo "2"
        exit $RET_CRIT
fi
