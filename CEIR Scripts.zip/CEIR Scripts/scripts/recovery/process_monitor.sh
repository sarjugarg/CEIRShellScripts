set -x
status=""
op_name=$1
main_script_path="/u01/ceirapp/cdrpreprocessor/$1/"
script_name="script_v2.sh"
status_base_path="/u01/ceirapp/status/$1"
recovery_script_path="/u01/ceirapp/scripts/recovery/"
DATE=$(date -d "+1 days" "+%Y-%m-%d")
output_path="/u01/ceirapp/cdrpreprocessor"

main_script_status=`ps -ef | grep script_v2.sh| grep -v vi | grep -v grep`
if [ "$main_script_status" != "" ]
then
	exit
fi

validate(){
query=$1
filename=$2

`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb << EOF
   SET ECHO OFF
   SET FEEDBACK OFF
   SET PAGES 0
   SET SERVEROUTPUT ON
   SET VERIFY OFF

   SET head on
   SET COLSEP ,
   SET TRIMSPOOL ON
   set trimout on
   set linesize 1000
   spool "$output_path/${filename}"

   ${query};
  commit;
   spool off 
 
EOF
        `
}

if [ "$op_name" == "smart" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "metfone" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "cellcard" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "seatel" ]
then
	src_name=$(cat $op_name)
else
	echo "Operator not found"
fi

i=0
while true
do
date=$(date -d "-$i days" "+%Y-%m-%d")
month=$(date -d "-$i days" "+%m")
echo month: $month
MONTH=$(date -d "-$i days" +"%^B")
echo MONTH: $MONTH
year=$(date -d "-$i days" "+%Y")
echo year: $year
day=$(date -d "-$i days" "+%d")
echo day: $day

query="delete from cdr_pre_processing_report where operator_name='$op_name' and created_on<=to_date('$DATE','YYYY-MM-DD') and created_on>=to_date('$date','YYYY-MM-DD')"


if [ -d "$status_base_path/$year/$month/$day" ]
then
	echo "Folder exists"
	cd $status_base_path/$year/$month/$day
	status=$(cat status.txt | grep done)
	if [ "$status" != "" ]
	then
		if [ $i -lt 0 ]
		then
			echo "Running Recovery For $i Days"
			echo "Going to delete entries from table"
			validate "$query" test.txt
			wait $!
			if [ -f P1.txt ] ; then
				rm test.txt
			fi
			cd $main_script_path
			./$script_name $op_name $src_name &
			exit
		else
			echo "done tag found in status.txt"
			echo "Process was completed sucessfully"
			exit
		fi
	else
		echo "done tag not found in status.txt"
		echo "Going to start recovery script"
		validate "$query" test.txt
		wait $!
		if [ -f P1.txt ] ; then
			rm test.txt
		fi
		cd $recovery_script_path
		./recovery.sh "$op_name" "$year" "$MONTH" "$day"
		cd $main_script_path
		./$script_name $op_name $src_name &

		exit
	fi
else 
	i=$((i-1))
fi
done
