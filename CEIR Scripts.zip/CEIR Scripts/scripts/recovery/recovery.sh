#!/bin/bash

op_name=$1
year=$2
month=$3
day=$4
src_name=""
main_script_path="/u01/ceirapp/cdrpreprocessor/$1/"
cdrprocessor_path="/u01/ceirapp/cdrprocessor/"
all_path="/u02/ceirdata/processed_cdr/$1/all"
script_name="script_v2.sh"

if [ "$op_name" == "smart" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "metfone" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "cellcard" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "seatel" ]
then
	src_name=$(cat $op_name)
else
	echo "Operator not found"
fi

i=0
for j in $src_name
do
	array[$i]=$j;
	echo "for ${array[$i]}"
	processing_file_path="/u02/ceirdata/processed_cdr/$1/${array[$i]}/processed/$year/$month/$day"
	raw_cdr_path="/u02/ceirdata/raw_cdr/$1/${array[$i]}/"
	output_path="/u02/ceirdata/processed_cdr/$1/${array[$i]}/output"
	error_path="/u02/ceirdata/processed_cdr/$1/${array[$i]}/error/$year/$month/$day"
	if [ -d $processing_file_path ]
	then
		echo "moving files from processing back to raw for ${array[$i]}"
		find "$processing_file_path"/ -type f -iname '*' -exec mv -t "$raw_cdr_path" {} \+
		#mv "$processing_file_path"/* "$raw_cdr_path"
		wait $!
	fi
	if [ -d $output_path ]
	then
		echo "deleting output files created for ${array[$i]}"
		rm -rf "$output_path"/*
		wait $!
	fi
	if [ -d $error_path ]
	then
		echo "deleting error files created for ${array[$i]}"
		rm -rf "$error_path"/*
		wait $!
	fi
	i=$(($i+1));
done

if [ -d $all_path ]
then
	echo "deleting all folder for $op_name"
	rm -rf "$all_path"/*
fi

#cd $main_script_path

#./$script_name $op_name $src_name &

