#!/bin/bash
#cleanUp Files
set -x
op_name=$1
src_name=""
main_script_path="/u01/ceirapp/cdrpreprocessor/$1/"
all_path="/u02/ceirdata/processed_cdr/$1/all"
inputP2="/u02/ceirdata/raw_cdr/$1/all"
outputP2="/u02/ceirdata/processed_cdr/$1/all/output"
inputP3="/u01/ceirapp/cdrprocessor/$1/"
inputSQL="/u01/ceirdata/Sql_Loader_Files/$1"

year=$2 
month=$3
day=$4

mkdir -p /u01/ceirapp/cdrRecoveryProcess/recoveryFilelogs/$2/$3/$4/

logFilePath="/u01/ceirapp/cdrRecoveryProcess/recoveryFilelogs/$2/$3/$4"

script_name="cleanup"

if [ "$op_name" == "smart" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "metfone" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "cellcard" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "seatel" ]
then
	src_name=$(cat $op_name)
else
	echo "Operator not found"
fi

i=0
for j in $src_name
do
	array[$i]=$j;
	echo "for ${array[$i]}"
	output_path="/u02/ceirdata/processed_cdr/$1/${array[$i]}/output"
	error_path="/u02/ceirdata/processed_cdr/$1/${array[$i]}/error/$year/$month/$day"
	processing_file_path="/u02/ceirdata/processed_cdr/$1/${array[$i]}/processed/$year/$month/$day"
	raw_cdr_path="/u02/ceirdata/input/$1/${array[$i]}/"
        
	if [ -d $processing_file_path ]
	then
		echo "moving files from processing back to raw for ${array[$i]}"
                ls $processing_file_path > $logFilePath/$1-${array[$i]}.txt
                find "$processing_file_path"/ -type f -iname '*' -exec mv -t "$raw_cdr_path" {} \+
		#mv "$processing_file_path"/* "$raw_cdr_path"
		wait $!
	fi
#	if [ -d $output_path ]
#	then
		echo "deleting output files created for ${array[$i]}"
		rm -rf "$output_path"/*
		wait $!
#	fi
#	if [ -d $error_path ]
#	then
		echo "deleting error files created for ${array[$i]}"
#		rm -rf "$error_path"/*
		wait $!
#	fi
	i=$(($i+1));
done

#if [ -d $all_path ]
#then
	echo "deleting all folder for $op_name"
	rm -rf "$all_path"/*
#fi


echo "delete from Input P2 /all " 
rm -rf "$inputP2"/*

echo "Delete from Output P3 "
rm -rf "$outputP2"/*

echo "Input P3 " 
find $inputP3 -iname '*.dat*' -exec rm  '{}'  \;

echo " Input SQL" 
find $inputSQL -iname '*.sql*' -exec rm  '{}'  \;



