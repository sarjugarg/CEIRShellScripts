#!/bin/bash
set -x
op_name=$1
VAR=""
D=""
repd=$(date +"%Y_%m_%d")
output_path=/u01/ceirapp/scripts/deleteInputfromSSHFile
cd $output_path
src_name=""
export LD_LIBRARY_PATH=/home/ceirapp/oracleclient/instantclient_19_12
export PATH=$PATH:$LD_LIBRARY_PATH
export TNS_ADMIN=/home/ceirapp/oracleclient/instantclient_19_12/network/admin

filename=query-$1-$4.txt
echo $2
echo $3
       getfile_query="select file_name from CDR_PRE_PROCESSING_REPORT where to_char(CREATED_ON,'YYYY-MM-DD') >= '$2' and to_char(CREATED_ON,'YYYY-MM-DD') <='$3' and OPERATOR_NAME='$op_name' and source_name='$4';"

dbStatusUpdate()
{
        `sqlplus CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb << EOF
                SET ECHO OFF
                SET FEEDBACK OFF
                SET PAGES 0
                SET SERVEROUTPUT ON
                SET VERIFY OFF
                SET head on
                SET COLSEP ,
                SET TRIMSPOOL ON
                set trimout on
                set linesize 1000
                spool "$output_path/$filename"
           ${getfile_query}
spool off
            commit ;
EOF
`
}

dbStatusUpdate 
