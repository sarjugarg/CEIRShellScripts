

set -x
op_name=$1
VAR=""
output_path=/u01/ceirapp/scripts/deleteInputfromSSHFile
cd $output_path
src_name=""


dbStatusUpdate(){ 
p3_query="update cdr_file_records_db set STATUS_SIG1= 'DONE' ,STATUS_SIG2= 'DONE' where FILE_NAME = '$1'   "
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb << EOF
   ${p3_query};
    commit 
EOF
        `
}






if [ "$op_name" == "smart" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "metfone" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "cellcard" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "seatel" ]
then
	src_name=$(cat $op_name)
else
	echo "Operator not found"
fi

i=0
for j in $src_name
do
	array[$i]=$j;
	echo "for ${array[$i]}"
          input_cdr_path="/u02/ceirdata/input/$1/${array[$i]}"
          output_file_name=$output_path/$1-${array[$i]}.txt

          while IFS= read -r line; do
          echo "Text read from file: $line"
		dbStatusUpdate $line
          rm -rf $input_cdr_path/$line
          done < "$output_file_name"          

done
