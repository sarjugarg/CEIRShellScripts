#!/bin/bash
current_date=$(date +%Y-%m-%d)
past_date=$(date -d "$current_date -30 days" +%Y-%m-%d)

fpath=/u01/ceirapp/scripts/deleteInputfromSSHFile
cd $fpath


touch test123.txt
