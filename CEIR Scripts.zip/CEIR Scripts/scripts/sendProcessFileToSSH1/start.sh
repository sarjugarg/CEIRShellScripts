#!/bin/bash
set -x
op_name=$1
VAR=""
D=""
repd=$(date +"%Y_%m_%d")

serverId="Sig-01"
remoteServerIp="172.24.2.60"
#serverId=$2
output_path=/u01/ceirapp/scripts/sendProcessFileToSSH1
cd $output_path
remoteFileLocation=/u01/ceirapp/scripts/deleteInputfromSSHFile

if [ $2 == $VAR ]
then


validate2(){
query="select created_on from cdr_process_status where STATUS= 'Start' and  process_name = 'scriptV2' and SERVER_ID = '$serverId' and  OPERATOR = '$op_name'  order by id  desc fetch next 1 rows only "
filename=$1
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb << EOF
   SET ECHO OFF
   SET FEEDBACK OFF
   SET PAGES 0
   SET SERVEROUTPUT ON
   SET VERIFY OFF
   SET head on
   SET COLSEP ,
   SET TRIMSPOOL ON
   set trimout on
   set linesize 1000
   spool "$output_path/${filename}"
   ${query};
   spool off 
EOF
        `
}

validate2  "P2.txt"
wait $!
#cd $output_path
result2=`cat P2.txt| tr -d " \t\n\r" `
echo $result2
D=`echo $result2| cut -c1-9`
#D="01-FEB-2022"
else
D=$2
fi
echo "Date : $D"
DAY=$(date -d "$D" '+%d') 
DAYN=$(echo $DAY | sed 's/^0*//')
MONTH=$(date -d "$D" '+%B')
YEAR=$(date -d "$D" '+%Y')
echo "Day: $DAY"
echo "DayNZ: $DAYN"
echo "Month: ${MONTH^^}"
echo "Year: $YEAR"
 
     rm P2.txt
src_name=""
year=$YEAR 
month=${MONTH^^}
day=$DAYN

if [ "$op_name" == "smart" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "metfone" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "cellcard" ]
then
	src_name=$(cat $op_name)
elif [ "$op_name" == "seatel" ]
then
	src_name=$(cat $op_name)
else
	echo "Operator not found"
fi

i=0
for j in $src_name
do
	array[$i]=$j;
	echo "for ${array[$i]}"
	processing_file_path="/u02/ceirdata/processed_cdr/$1/${array[$i]}/processed/$year/$month/$day/"
#        input_cdr_path="/u02/ceirdata/input/$1/${array[$i]}"
 	output_file_name=$output_path/$1-${array[$i]}.txt
		echo "getting files from processed_cdr  for ${array[$i]}"

if [ -d "$processing_file_path" ] 
then
 	echo "Directory /path/to/dir exists."
	cd  $processing_file_path
        ls > $output_file_name
else
    echo " Directory /path/to/dir does not exists"
    exit 0;
fi		
                #cd  $processing_file_path
		#ls > $output_file_name
 
  
#cd /u01/ceirapp/cdr_process/scripts/
cd  $output_path
scp -rP 22022 $1-${array[$i]}.txt ceirapp@$remoteServerIp:$remoteFileLocation
 mv $output_file_name /u02/ceirdata/scripts/sendProcessFileToSSH1/fileOldDir/$1-${array[$i]}_${D}.txt

#rm P2.txt
echo "Done"
done
 ssh ceirapp@$remoteServerIp -p 22022 " cd /u01/ceirapp/scripts/deleteInputfromSSHFile/; ./start.sh $1 "

exit ;
