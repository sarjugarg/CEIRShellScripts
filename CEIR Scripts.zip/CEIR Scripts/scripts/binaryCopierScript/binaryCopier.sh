#!/bin/sh
declare -a arr=("/u01/ceirapp/cdrpreprocessor/cellcard/all" "/u01/ceirapp/cdrpreprocessor/cellcard/cc_ggsn" "/u01/ceirapp/cdrpreprocessor/cellcard/cc_msc02" "/u01/ceirapp/cdrpreprocessor/cellcard/cc_msc03" "/u01/ceirapp/cdrpreprocessor/cellcard/cc_zmsc71" "/u01/ceirapp/cdrpreprocessor/cellcard/cc_zmsc72" "/u01/ceirapp/cdrpreprocessor/cellcard/cc_zmsc73" "/u01/ceirapp/cdrpreprocessor/metfone/all" "/u01/ceirapp/cdrpreprocessor/metfone/mf_msc09" "/u01/ceirapp/cdrpreprocessor/metfone/mf_msc10" "/u01/ceirapp/cdrpreprocessor/metfone/mf_msc11" "/u01/ceirapp/cdrpreprocessor/metfone/mf_msc14" "/u01/ceirapp/cdrpreprocessor/metfone/mf_msc15" "/u01/ceirapp/cdrpreprocessor/metfone/mf_msc16" "/u01/ceirapp/cdrpreprocessor/metfone/mf_sgsn1" "/u01/ceirapp/cdrpreprocessor/seatel/all" "/u01/ceirapp/cdrpreprocessor/seatel/st_p_gw" "/u01/ceirapp/cdrpreprocessor/smart/all" "/u01/ceirapp/cdrpreprocessor/smart/sm_msc01" "/u01/ceirapp/cdrpreprocessor/smart/sm_msc02" "/u01/ceirapp/cdrpreprocessor/smart/sm_sgsn_scdr" "/u01/ceirapp/cdrpreprocessor/smart/sm_sgsn_sgwcdr")
cd /u01/ceirapp/cdrpreprocessor/smart/sm_ims/
f="FileReaderHash-0.0.1-SNAPSHOT.jar"
for i in "${arr[@]}"
do
if [ -e $i/$f ];
then
        echo "$f exist "
        mv -b $i/$f $i/FileReaderHash-0.0.1-SNAPSHOT_backupV8.0.jar
        echo "file backup taken"
else
   echo "$f Not exist"
fi

cp -v "$f" $i
echo "file copied"
done
