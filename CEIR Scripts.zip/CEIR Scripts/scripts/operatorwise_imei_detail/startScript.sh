set -x

year=$1
month=$2

dbStatusUpdate(){ 
query=$1
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb << EOF
   ${query};
    commit 
EOF
        `
}


p1_query="insert into   operatorWise_imei_details (year , month ,  NEWCOUNTINUSGDB,USECOUNTINUSGDB ,NEWCOUNTINDUPDB, USECOUNTINDUPDB ) values(     '$year', '$month' ,( select count(*) from  device_usage_db where IMEI_ARRIVAL_TIME like '%$year$month%' ),  ( select count(*) from  device_usage_db where UPDATE_IMEI_ARRIVAL_TIME like '%$year$month%') ,   ( select count(*) from  device_duplicate_db where IMEI_ARRIVAL_TIME like '%$year$month%' ),  ( select count(*) from  device_duplicate_db where UPDATE_IMEI_ARRIVAL_TIME like '%$year$month%')    )   "
p2_query="update operatorWise_imei_details  set TOTALNEWCOUNT = NEWCOUNTINUSGDB + NEWCOUNTINDUPDB , TOTALUSEDCOUNT = USECOUNTINUSGDB + USECOUNTINDUPDB where year = '$year' and month = '$month' "    

dbStatusUpdate "$p1_query"
dbStatusUpdate "$p2_query"



