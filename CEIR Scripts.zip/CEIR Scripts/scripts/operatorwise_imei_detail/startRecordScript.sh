set -x

year=$1
month=$2

dbStatusUpdate(){ 
query=$1
`sqlplus -s CRESTELCEIR/CRESTELCEIR123#@//PRO-DBR-SCAN:1522/dmcprdb << EOF
   ${query};
    commit 
EOF
        `
}


p2_query=" insert into opertor_wise_record_count (opertor ,source,record_count,year , month ) 
    select   OPERATOR_NAME , SOURCE_NAME , sum (TOTAL_RECORDS)  , '$year' , '$month' from ( select distinct (FILE_NAME) ,	TOTAL_RECORDS , OPERATOR_NAME , SOURCE_NAME  from cdr_pre_processing_report where FILE_NAME like '%$year$month%' and SOURCE_NAME != 'all' and FILE_TYPE = 'I'group by OPERATOR_NAME , SOURCE_NAME  , file_name , TOTAL_RECORDS  ) group by OPERATOR_NAME , SOURCE_NAME order by OPERATOR_NAME , SOURCE_NAME  "    

dbStatusUpdate "$p2_query"



