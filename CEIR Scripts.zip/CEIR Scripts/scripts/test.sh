#!/bin/bash
set -x
op_name=$1
VAR=""
D=""
fpath=/u01/ceirapp/scripts/deleteInputfromSSHFile
cd $fpath

if [ "$op_name" == "smart" ]
then
        src_name=$(cat $op_name)
elif [ "$op_name" == "metfone" ]
then
        src_name=$(cat $op_name)
elif [ "$op_name" == "cellcard" ]
then
        src_name=$(cat $op_name)
elif [ "$op_name" == "seatel" ]
then
        src_name=$(cat $op_name)
else
        echo "Operator not found"
fi


i=0
for j in $src_name
do
        array[$i]=$j;
        echo "for ${array[$i]}"
./get_filename.sh "$1" "$2" "$3" "${array[$i]}"

echo "Done"
done

./start.sh $1

#while read -r line;
#do
#   echo "$line" ;
#done < input.file
