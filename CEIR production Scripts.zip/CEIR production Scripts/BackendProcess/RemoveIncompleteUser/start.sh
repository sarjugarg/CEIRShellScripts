
#!/bin/bash
VAR=""
cd  /u01/ceirapp/BackendProcess/RemoveIncompleteUser

build="BackendGenericProc.jar"
process_name="REMOVE_IN_COMPLETE_USER"

status=`ps -ef | grep $build | grep java`
if [ "$status" != "$VAR" ]
then
 echo "nothing"
 echo $status
else
 echo "to start"
java -jar $build $process_name -Dspring.config.location=:./application.properties -Dlog4j.configurationFile=./log4j2.xml 1>/u02/ceirdata/BackendProcess/RemoveIncompleteUser/log.log 2>/u02/ceirdata/BackendProcess/RemoveIncompleteUser/error.log 
fi

exit 0
