#!/bin/bash
if [ -n "$1" ]; then
	while true;
	do
		java -Dlogging.config=./logback.xml -jar ceirfilecopier.jar -Dspring.config.location=:./application.properties &
		sleep $1
	done
else
	echo "Thead sleep time like 10,20,30..."
fi
