#!/bin/bash

VAR=""
sys_ip_file="sys_ip.conf"
system_port="22022"

local_path="/u01/ceirapp/apache-tomcat-9.0.34/webapps/docs/ceir/"
remote_server_file_path="/u01/ceirapp/apache-tomcat-9.0.34/webapps/docs/ceir/"
remote_server_username="ceirapp"
remote_server_port="22022"

secondary=($(cat $sys_ip_file | grep S))
echo "Secondary ip is ${secondary:2:${#secondary}}"
secondary_ip=${secondary:2:${#secondary}}
nc -z $secondary_ip $system_port > /dev/null
t1=$?
echo "Secondary IP Status: "$t1

if [ "$t1" -eq 0 ]
then
	echo "Starting sync with another server"
	rsync -crlOt -avzhe 'ssh -p '$remote_server_port "$local_path" "$remote_server_username@$secondary_ip:$remote_server_file_path" > /dev/null
	if [ $? -eq 0 ]
	then
		echo "Sync completed with remote server"
	else
		echo "Sync failed with remote server"
	fi
else
	echo "Cannot connect with remote server, sync failed"
fi
