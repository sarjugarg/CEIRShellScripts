#!/bin/bash
#0:0:OK=Process is runing
#1:1:Down=Process is down
#2=Process does not exist
set -x
VAR=""
cd /u01/ceirapp/BackendProcess/RemoveBlacklistData
if [ -e CEIRCdrParser.jar ]
 then
    status=`ps -ef |  grep DeleteFromBlackList | grep java`
   if [ "$status" != "$VAR" ]
     then
       echo 0:0:OK
     else
echo Plain
     java  -Dlog4j.configuration=file:./conf/log4j.properties -cp ./lib/*:./CEIRCdrParser.jar com.glocks.parser.DeleteFromBlackList
   fi
else
 echo 2
fi
