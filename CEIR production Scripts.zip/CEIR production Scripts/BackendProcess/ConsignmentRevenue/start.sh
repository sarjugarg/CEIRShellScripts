
#!/bin/bash
VAR=""
#cd  /home/ubuntu/CEIR/backend-process
#cd /home/ceirapp/ceir/Process/individual_process
cd /u01/ceirapp/BackendProcess/ConsignmentRevenue
build="BackendGenericProc.jar"
#build="backend-process-0.0.1.jar"
process_name="CONSIGNMENT_REVENUE"

status=`ps -ef | grep $build | grep java`
if [ "$status" != "$VAR" ]
then
 echo "nothing"
 echo $status
else
 echo "to start"
java -jar $build $process_name -Dspring.config.location=:./application.properties -Dlog4j.configurationFile=./log4j2.xml 1>/u02/ceirdata/BackendProcess/ConsignmentRevenue/log.log 2>/u02/ceirdata/BackendProcess/ConsignmentRevenue/error.log 
fi

exit 0
