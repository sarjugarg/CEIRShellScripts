
 
#!/bin/bash
VAR=""
cd /u01/ceirapp/BackendProcess/BlackList
status=`ps -ef | grep BlackList | grep java`
if [ "$status" != "$VAR" ]
then
 echo "nothing"
 echo $status
else
 echo "to start"  
java -Dlog4j.configuration=file:./log4j.properties -jar BlackListProcess.jar -Dspring.config.location=:./application.properties 1>/u02/ceirdata/BackendProcess/BlackList/log.txt 2>/u02/ceirdata/BackendProcess/BlackList/error.txt
sleep 5 
cd /u01/ceirapp/BackendProcess/BlackListFileProcess/
java -Dlog4j.configuration=file:./log4j.properties -jar BlackListFileProcess.jar -Dspring.config.location=:./application.properties 1>/u02/ceirdata/BackendProcess/BlackListFileProcess/log.txt 2>/u02/ceirdata/BackendProcess/BlackListFileProcess/error.txt 
fi
