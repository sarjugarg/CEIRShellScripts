cd /home/ceirapp/ceir/ceir_parser 
nohup       java  -jar BasicApplication-0.1.jar &
 
