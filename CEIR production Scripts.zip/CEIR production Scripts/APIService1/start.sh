VAR=""
build_path="/u01/ceirapp/APIService1/"
build="apiservice1.jar"
cd $build_path
status=`ps -ef | grep $build | grep java`
if [ "$status" != "$VAR" ]
then
 echo "Process Already Running"
else
 echo "Starting Process"
#java -jar $build -Dspring.config.location=:./application.properties -Dlog4j.configurationFile=./log4j2.xml 1>>log-$(date -u +"%Y-%m-%d").txt 2>error-$(date -u +"%Y-%m-%d").txt &
 java -Dlogging.config=./logback.xml -jar $build -Dspring.config.location=:./application.properties >> /u02/ceirdata/APIService1/log.log 2>> /u02/ceirdata/APIService1/error.log &
 echo "Process Started"
fi

