#!/bin/bash
VAR=""
DPATH="/u01/ceirapp/APIService4/"
PNAME="apiservice4.jar"
cd $DPATH 
status=`ps -ef | grep $PNAME | grep java`
if [ "$status" != "$VAR" ]
then
 echo "The process is already running"
 echo $status
else
 echo "The process is not running. Starting the process"
 #java -jar apiservice4.jar -Dspring.config.location=:./application.properties -Dlog4j.config=./log4j2.xml 1>>log.txt 2>error.txt &
 java -Dlogging.config=./logback.xml -jar $PNAME -Dspring.config.location=:./application.properties 1>/u02/ceirdata/APIService4/log.log 2>/u02/ceirdata/APIService4/error.log &
 echo "Process started"
fi
