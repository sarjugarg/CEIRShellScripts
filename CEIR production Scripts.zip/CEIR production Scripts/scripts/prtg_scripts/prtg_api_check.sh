#!/bin/sh

#0:0:OK=Process is runing
#1:1:Down=Process is down
#2=Process does not exist

# Return Values
RET_OK="0"
RET_WARN="1"
RET_CRIT="2"
RET_UNKN="3"

path=$1
proc_name=$2
VAR=""

############################################

cd $path
if [ -e $proc_name ]
 then
   status=`ps -ef | grep $proc_name | grep -v grep`
   if [ "$status" != "$VAR" ]
     then
       echo 0:0:OK
           exit $RET_OK
     else
       echo 1:1:Down
           exit $RET_WARN
   fi
else
 echo 2:2:Does not exist
 exit $RET_CRIT
fi
