#!/bin/sh

#0:0:OK=Process is runing
#1:1:Down=Process is down
#2=Process does not exist

# Return Values
RET_OK="0"
RET_WARN="1"
RET_CRIT="2"
RET_UNKN="3"

############################################

echo "exit" | sqlplus -L CRESTELCEIR/CRESTELCEIR@//dmc-prod-db:1521/dmcproddb | grep Connected > /dev/null

if [ $? -eq 0 ]
then
   echo "0:0:OK"
   exit $RET_OK
elif [ $? -eq 1 ]
then
        echo "1:1:DOWN"
        exit $RET_WARN
else
   echo "2"
   exit $RET_CRIT
fi
