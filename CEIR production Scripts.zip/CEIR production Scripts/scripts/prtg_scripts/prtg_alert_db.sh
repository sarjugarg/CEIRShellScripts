#!/bin/bash

# Return Values
RET_OK="0"
RET_WARN="1"
RET_CRIT="2"
RET_UNKN="3"

alert_code=$1
#query="select description from running_alert_db where MODIFIED_ON>=current_timestamp - interval '1' day and alert_id='$alert_code' order by MODIFIED_ON desc fetch first 1 rows only"
############################################

description=`sqlplus -s CRESTELCEIR/CRESTELCEIR@//dmc-prod-db:1521/dmcproddb << EOF
SET ECHO OFF
   SET FEEDBACK OFF
   SET PAGES 0
   SET SERVEROUTPUT ON
   SET VERIFY OFF

   SET head on
   SET COLSEP ,
   SET TRIMSPOOL ON
   set trimout on
   set linesize 1000
   WHENEVER SQLERROR EXIT SQL.SQLCODE;
        select description from running_alert_db where MODIFIED_ON>=current_timestamp - interval '5' minute and alert_id='$alert_code' order by MODIFIED_ON desc fetch first 1 rows only;
EOF
        `
sql_return_code=$?

if [ $sql_return_code != 0 ]
then
        echo "2:SQL ERROR CODE $sql_return_code"
        exit $RET_CRIT;
fi

if [ "$description" != "" ]
then
        echo "1:$description"
        exit $RET_WARN
else
        echo "0:OK"
        exit $RET_OK
fi

