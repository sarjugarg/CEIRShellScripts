VAR=""
build_path="/u01/ceirapp/APIService3/"
build="apiservice3.jar"
cd $build_path
status=`ps -ef | grep $build | grep java`
if [ "$status" != "$VAR" ]
then
 echo "Process Already Running"
else
 echo "Starting Process"
java  -Xmx1024m -Xms256m  -Dlog4j.configuration=file:./log4j.properties -jar $build -Dspring.config.location=:./application.properties 1>/u02/ceirdata/APIService3/logI3.txt 2>/u02/ceirdata/APIService3/error.txt &
 echo "Process Started"
fi
